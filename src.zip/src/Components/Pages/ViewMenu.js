import React from "react";
function ViewMenu() {
  return (
    <div className="page-heading">
      <h1>View Menu</h1>
    </div>
  );
}

export default ViewMenu;