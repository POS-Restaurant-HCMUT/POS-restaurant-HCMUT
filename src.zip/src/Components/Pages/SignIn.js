import React from "react";
function Demo() {
  return (
    <div className="page-heading">
      <h1>Try For Free</h1>
    </div>
  );
}

export default Demo;