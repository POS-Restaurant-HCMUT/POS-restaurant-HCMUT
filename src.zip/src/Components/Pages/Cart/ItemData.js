let ItemData = [
      {
        id: '1',
        name: 'Latte',
        price: 30000,
        image: 'https://images.foody.vn/res/g73/729649/s120x120/06606261-c5ce-43c3-d2ef-550c38a976c2.jpg',
        qty: 1,
      },
      {
        id: '2',
        name: 'Hot coffee',
        price: 15000,
        image: 'https://images.foody.vn/res/g73/729649/s120x120/b322e349-0628-4b8d-b73d-35fc82518fbe.jpg',
        qty: 1,
      },
      {
        id: '3',
        name: 'Tiramisu',
        price: 10000,
        image: 'https://images.foody.vn/res/g73/729649/s120x120/0c46a88a-6f37-4a7b-9f7d-b7252876ce3f.jpg',
        qty: 1,
      },
      {
        id: '4',
        name: 'Green Tea',
        price: 20000,
        image: 'https://images.foody.vn/res/g73/729649/s120x120/0c46a88a-6f37-4a7b-9f7d-b7252876ce3f.jpg',
        qty: 3,
      },
];
  export default ItemData;