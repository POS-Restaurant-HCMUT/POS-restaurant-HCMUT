export let DishesInCart = [
    {
        id: '1',
        img: 'https://media.vov.vn/sites/default/files/styles/large/public/2020-09/26_1.jpg',
        name: 'Thịt kho tàu',
        category: 'Food',
        desc: 'Ngon bá cháy',
        price: 100000,
        qty: 1,
    },
];