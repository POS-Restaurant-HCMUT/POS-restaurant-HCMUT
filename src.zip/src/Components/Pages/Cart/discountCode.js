const discountCode = [
    {
        id: "1",
        value: "AS123456",
        discount: 2000,
    },
    {
        id: "2",
        value: "BD123456",
        discount: 5000,
    },
    {
        id: "3",
        value: "QR123456",
        discount: 10000,
    },
];

export default discountCode;