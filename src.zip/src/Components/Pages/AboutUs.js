import React from "react";
function AboutUs() {
  return (
    <div className="page-heading">
      <h1>About us</h1>
    </div>
  );
}

export default AboutUs;