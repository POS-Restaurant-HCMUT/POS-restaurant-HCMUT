export const MenuList = [
  {
    title: "Home",
    url: "/",
    style: "fas fa-home",
  },
  {
    title: "View Menu",
    url: "/view-menu",
    style: "fas fa-book-open",
  },
  {
    title: "Cart",
    url: "/cart",
    style: "fas fa-shopping-cart",
  },
  {
    title: "About us",
    url: "/about-us",
    style: "far fa-smile-wink",
  },
  {
    title: "Sign in",
    url: "/demo",
  },
];
